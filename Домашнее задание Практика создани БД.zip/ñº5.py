import sqlite3
conn = sqlite3.connect("Blog.db")
cursore = conn.cursor()

cursore.execute('''
CREATE TABLE IF NOT EXISTS rubruics(
    id INTEGER PRIMARY KEY,
    name TEXT);
''')

cursore.execute('''
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY, 
    full_name TEXT, 
    brith_date DATE,
    role TEXT,
    registration_date DATE);
''')

cursore.execute('''
CREATE TABLE IF NOT EXISTS posts(
    id INTEGER PRIMARY KEY, 
    rubric_id INTEGER,
    user_id INTEGER,
    text TEXT,
    FOREIGN KEY (rubric_id) REFERENCES Rubrics(id),
    FOREIGN KEY (user_id) REFERENCES Users(id));
''')

conn.commit()

rubrics_data = [
    ('1', 'Technology'),
    ('2', 'Travel'),
    ('3', 'Food'),
    ('4', 'Lifestyle'),
    ('5', 'Fashion')
]
cursore.executemany('INSERT INTO rubrics (id, name) VALUES(?, ?);', rubrics_data)

users_data = [
    (1, 'John Doe', '1990-05-15', 'author', '2023-01-10'),
    (2, 'Jane Smith', '1985-09-20', 'reader', '2022-08-05'),
    (3, 'Alex Johnson', '1998-03-03', 'author', '2023-03-18'),
    (4, 'Emily Brown', '2001-11-28', 'reader', '2023-06-22'),
    (5, 'Michael Wilson', '1978-07-12', 'admin', '2021-12-02')
]
cursore.executemany('INSERT INTO users (id, full_name, birth_date, role, regisrtation_date) VALUES (?, ?, ?, ?, ?)', users_data)

posts_data = [
    (1, 1, 1, 'Exploring the Latest Tech Trends'),
    (2, 2, 3, 'A Journey Through the Mountains'),
    (3, 3, 1, 'Delicious Recipes for Every Foodie'),
    (4, 4, 4, 'Balancing Work and Hobbies'),
    (5, 5, 2, 'Summer Fashion Essentials')
]
cursore.executemany('INSERT INTO posts (id, rubric_id, user_id, text) VALUES (?, ?, ?, ?);', posts_data)
conn.commit()
conn.close()