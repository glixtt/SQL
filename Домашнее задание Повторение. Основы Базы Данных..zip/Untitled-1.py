class Dish: 
    def __init__(self, name, price): 
        self.name = name 
        self.price = price 
 
class Order: 
    def __init__(self, table): 
        self.table = table 
        self.dishes = [] 
 
    def add_dish(self, dish): 
        self.dishes.append(dish) 
 
    def remove_dish(self, dish): 
        if dish in self.dishes: 
            self.dishes.remove(dish) 
        else: 
            print(f"{dish.name} не найден в заказе.") 
 
    def calculate_total(self): 
        total_price = sum(dish.price for dish in self.dishes) 
        return total_price 
 
def print_order(order): 
    print(f"Заказ для столика: {order.table}\n") 
    print("Блюда в заказе:") 
    for dish in order.dishes: 
        print(f"{dish.name}: {dish.price} руб.") 
    total_price = order.calculate_total() 
    print(f"Общая стоимость заказа: {total_price} руб.\n") 
 
# Создание блюд 
dish1 = Dish("Стейк", 25.99) 
dish2 = Dish("Салат", 12.99) 
dish3 = Dish("Паста", 18.99) 
 
 
# Создание заказов 
order1 = Order("Столик 1") 
order2 = Order("Столик 2") 
 
 
#  Удаление блюда из заказа 
order1.remove_dish(dish2) 
 
# Добавление блюд в заказы 
order1.add_dish(dish1) 
order1.add_dish(dish3) 
order2.add_dish(dish2) 
 
# Вывод информации о заказах 
print_order(order1) 
print_order(order2)