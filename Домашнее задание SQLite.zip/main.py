import sqlite3

conn = sqlite3.connect('MyContacts.db')
cur = conn.cursor()

cur.execute('''
CREATE TABLE IF NOT EXISTS Contacts(
    id INTEGER PRIMARY KEY,
    name TEXT,
    phone TEXT,
    email TEXT
);
    ''')


more_contacts = [('1','Peter', '+19856545565', 'peter@yandex.ru'), 
              ('2','Bruce', '+79042873851', 'bruse565@gmail.com'),
              ('3','Elliot', '+78566542636', 'Elliot789@md.ru'),
              ('4','Graham ', '+15689652345', 'Graham5688@gmail.com'),
              ('5','Grant ', '+78566541235', 'Grant4568@gmail.com')]

cur.executemany('INSERT INTO Contacts VALUES (?, ?, ?, ?)', more_contacts)



select_Contacts_all = 'SELECT * FROM Contacts'
cur.execute(select_Contacts_all)
conn.commit()
rows = cur.fetchall()

for row in rows:
    print(f'Все контакты: {row}')

select_Contacts_phone_name = 'SELECT name, phone FROM Contacts WHERE phone LIKE "+1%"'
cur.execute(select_Contacts_phone_name)
conn.commit()
rows = cur.fetchall()
for row in rows:
    print(f'Все контакты с номером на +1: {row}')




select_Contacts_email = 'SELECT * FROM Contacts WHERE email LIKE "%gmail%"'
cur.execute(select_Contacts_email)
conn.commit()
rows = cur.fetchall()
for row in rows:
    print(f'Все контакты, у которых в адресе электронной почты есть слово "gmail": {row}')



select_Contacts_up_name_phone = 'UPDATE Contacts SET name = "Jack", phone = "+1565899632" WHERE id = "1"'
print(f'Обновили имя и номер у id 1')

select_Contacts_all = 'SELECT * FROM Contacts'
cur.execute(select_Contacts_all)
conn.commit()
rows = cur.fetchall()

for row in rows:
    print(f'Все контакты с изменениями: {row}')

select_Contacts_up_name_phone = 'DELETE FROM Contacts WHERE `id` = 2;'
print(f'Удалили контакт с id 2')


select_Contacts_all = 'SELECT * FROM Contacts'
cur.execute(select_Contacts_all)
conn.commit()
rows = cur.fetchall()

for row in rows:
    print(f'Все контакты с изменениями: {row}')

conn.commit()


