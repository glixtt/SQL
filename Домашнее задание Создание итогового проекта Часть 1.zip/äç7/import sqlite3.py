import sqlite3 

connection = sqlite3.connect('jokes.db')
cursor = connection.cursor()  
cursor.execute("CREATE TABLE Jokes (id INTEGER PRIMARY KEY, joke TEXT)")   
jokes = [
    "Допустим, я дала тебе 5 яблок. А потом 3 забрала. Что у тебя остаётся?- Проблемы с доверием.",
    "Ляжешь просто полежать - уснёшь! Ляжешь почитать - уснёшь! Ляжешь телевизор посмотреть - уснёшь! Ляжешь поспать - хрен уснёшь!",
    "Зачем в норвежских тюрьмах решетки на окнах? Чтоб никто не залез и не жил там.",
    "Прапор спрашивает: -Кто поедет на картошку два шага вперед. Выходят два солдата. -Остальные пойдут пешком.",
    "Если у вас закончилась мазь от зуда, — Не спешите выбрасывать тюбик. Его уголком очень удобно чесаться."
    ]  
for joke in jokes:     
    cursor.execute("INSERT INTO Jokes (joke) VALUES (?)", (joke,))  
connection.commit()  
connection.close()
print(joke)